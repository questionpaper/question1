package com.cts.automatic_paper.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.automatic_paper.bean.LoginBean;
import com.cts.automatic_paper.service.LoginService;
import com.cts.automatic_paper.service.LoginServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LoginService loginService = new LoginServiceImpl();

		LoginBean bean = new LoginBean();
		bean.setUserName(request.getParameter("userName"));
		bean.setPassword(request.getParameter("password"));
		
		System.out.println("in servlet"+bean.getPassword()+bean.getPassword());
		RequestDispatcher dispatcher = null;
		
		if(loginService.validateUser(bean)) {
			System.out.println("true");
		dispatcher = request.getRequestDispatcher("AdminFrame.jsp");
		dispatcher.forward(request, response);
		}
		else {
			System.out.println("false");
			dispatcher=request.getRequestDispatcher("loginPage.jsp");
			dispatcher.forward(request, response);
		}
		
	}
}
