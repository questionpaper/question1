package com.cts.automatic_paper.dao;

import com.cts.automatic_paper.bean.LoginBean;

public interface LoginDAO {
	
	public boolean validateUser(LoginBean bean);

}