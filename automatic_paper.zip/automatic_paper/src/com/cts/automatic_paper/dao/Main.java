package com.cts.automatic_paper.dao;

import com.cts.automatic_paper.bean.LoginBean;

public class Main {

	public static void main(String[] args) {
		LoginDAO dao = new LoginDAOImpl();
		LoginBean bean = new LoginBean();
		bean.setUserName("shree");
		bean.setPassword("abhi");
		System.out.println(dao.validateUser(bean));
	}
}