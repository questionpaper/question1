package com.cts.automatic_paper.dao;


import com.cts.automatic_paper.bean.registerBean;

public interface registerDAO {
	public boolean RegisterUser(registerBean bean);

}