package com.cts.automatic_paper.dao;

import com.cts.automatic_paper.bean.Question;

public interface QuestionDAO {
	public boolean addUser(Question bean);

}