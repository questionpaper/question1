package com.cts.automatic_paper.service;

import com.cts.automatic_paper.bean.Question;

public interface QuestionService {
	public boolean addUser(Question bean);
}