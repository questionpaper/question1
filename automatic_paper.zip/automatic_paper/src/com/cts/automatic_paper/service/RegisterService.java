package com.cts.automatic_paper.service;
import com.cts.automatic_paper.bean.registerBean;

public interface RegisterService {
	public   boolean RegisterUser(registerBean bean) ;
		// TODO Auto-generated method stub
		
	

}