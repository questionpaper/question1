package com.cts.automatic_paper.service;

import com.cts.automatic_paper.dao.LoginDAO;
import com.cts.automatic_paper.dao.LoginDAOImpl;
import com.cts.automatic_paper.bean.LoginBean;

public class LoginServiceImpl implements LoginService{

	LoginDAO loginDAO = new LoginDAOImpl();
	public boolean validateUser(LoginBean bean) {
		// TODO Auto-generated method stub
		System.out.println(" Service called");
		return loginDAO.validateUser(bean);
	}

}