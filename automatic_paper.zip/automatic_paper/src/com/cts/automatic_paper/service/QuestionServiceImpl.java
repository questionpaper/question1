package com.cts.automatic_paper.service;

import com.cts.automatic_paper.dao.QuestionDAOImpl;
import com.cts.automatic_paper.bean.Question;
import com.cts.automatic_paper.dao.QuestionDAO;




public class QuestionServiceImpl implements QuestionService
{

	QuestionDAO questionDAO = new QuestionDAOImpl();
	public boolean addUser(Question bean) {
	
		return questionDAO.addUser(bean);
	}
	

}