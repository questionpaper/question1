package com.cts.automatic_paper.service;


import com.cts.automatic_paper.dao.RegisterDAOImpl;
import com.cts.automatic_paper.dao.registerDAO;
import com.cts.automatic_paper.bean.registerBean;



	public class RegisterServiceImpl implements RegisterService
{

		private registerDAO RegisterDAO = new RegisterDAOImpl();
		
		public boolean RegisterUser(registerBean bean) {
			return RegisterDAO.RegisterUser(bean);
		}
	}