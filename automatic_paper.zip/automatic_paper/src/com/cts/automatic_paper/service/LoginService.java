package com.cts.automatic_paper.service;

import com.cts.automatic_paper.bean.LoginBean;

public interface LoginService {
	public boolean validateUser(LoginBean bean);
}